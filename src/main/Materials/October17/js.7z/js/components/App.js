/**
 * Created by batmah on 16.10.16.
 */
import React, { Component } from 'react';
/*
const App = (props) => (
    <div>
        {props.children}
        <div>Hi {props.target}</div>
    </div>
);

App.propTypes = {
    target: React.PropTypes.string.isRequired
};

export default App;

*/

class App extends Component {
    constructor (props) {
        super(props);
        this.state = { text: ' '}
    }
    render() {
    return(
     <div>{this.props.target}</div>
    );
  }
}


App.propTypes = {
    target: React.PropTypes.string.isRequired
};

export default App;