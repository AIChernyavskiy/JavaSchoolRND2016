/** Created by batmah on 16.10.16. */
import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App'


ReactDOM.render(
<App target = "JAVA">Hello</App>,
document.getElementById('app')
);